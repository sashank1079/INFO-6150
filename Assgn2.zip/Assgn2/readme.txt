Used various html and html5 tags to build a personal protfolio website.
This website consists of 3 pages: HOME, PORTFOLIO and CONTACT. 

Tags used: <body>, <header>, <span>, <h1>, <span>, <ul>, <li>, mailto property,
tel property, <a>, <footer>

Used @media in CSS to add responsiveness to page.
Defined width 768 for ipad layout and max 365 min 350 for phones.

Hyerlinked social media and other handles using <a> in CONTACT page.

Created a timeline using css properties to make  vertical timeline which includes education and career paths.

Home page has a download button to download CV.

Used a backgroundless image in the home page to give more appeal to the hover effect.

Added a glow type effect using box shadow for the image in the home page. 

Used postion:fixed to keep the header and footer fixed.